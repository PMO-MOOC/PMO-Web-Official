from django.contrib import admin

# Register your models here.
from PMO.models import Home

admin.site.register(Home)