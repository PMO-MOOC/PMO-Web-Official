from django.shortcuts import render, render_to_response
from django.contrib.auth import authenticate, login, logout
# Create your views here.

from django.shortcuts import render, render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from PMO.models import Home


def index(request):
	
	if request.method == 'POST':
		r = Home(recent_upload = request.POST['anc'],pub_date = request.POST['date1'])
		r.save()
	
	home = Home.objects.order_by('id')
	obj_list = []
	obj_list1 = []
	
	for i in home:
		obj_list.append(i)
		
	obj_list1 = reversed(obj_list) 
	
	d = Home.objects.latest('id')	 
				   
	return render(request, 'PMO/announcement.html',{'home':obj_list1, 'd':d})
	
def archive(request,i_id):
	p = Home.objects.get(pk=i_id)
	
	#return HttpResponse(p.recent_upload)
	return render(request, 'PMO/archive.html', {'p':p})

def login_user(request):
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(username=username, password=password)
		if user is not None:
			if user.is_active:
				login(request, user)
				return render(request,'PMO/loggedin.html',{'user':user})
		else:
				return HttpResponse('User is not valid')		
	else:		
		return render(request, 'PMO/login.html')

def logout_user(request):
	logout(request)
	return render(request,'PMO/login.html')			
	