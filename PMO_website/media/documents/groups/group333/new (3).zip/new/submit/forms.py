# /uploadering/filebaby/forms.py

from django import forms

from submit.models import Groups


class GroupForm(forms.ModelForm):
    """Upload files with this form"""
    class Meta:
        model = Groups
        exclude = ('md5',)