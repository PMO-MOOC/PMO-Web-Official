from django.shortcuts import render, render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from submit.models import Groups, Partners
from django.template import RequestContext
from django.core.files.base import ContentFile
from django.core.files import File

from submit.forms import GroupForm


def index(request):
	groups = Groups.objects.all()
	return render(request, 'submit/form.html', {'groups':groups})


def detail(request, group_id):
	form = DocumentForm()
	doc = Groups.objects.get(pk=group_id)
	return render_to_response(
        'submit/result.html',
        {'doc': doc, 'form': form},
        context_instance=RequestContext(request)
    )

def add(request):
	
	r = Groups(group_name=request.POST['projName'],summary=request.POST['summary'],src_url=request.POST['srcurl'],doc_url=request.POST['docurl'])
	r.save()
	a = Partners(partner_name=request.POST['p1'],group=r)
	a.save()
	b= Partners(partner_name=request.POST['p2'],group=r)
	b.save()
	c= Partners(partner_name=request.POST['p3'],group=r)
	c.save()
	
	

	
	return render(request, 'submit/result.html', {'r': r})
	
	