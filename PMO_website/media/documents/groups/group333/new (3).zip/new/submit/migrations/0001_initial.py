# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import submit.models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Groups',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('group_name', models.CharField(max_length=200)),
                ('sub_date', models.DateField(verbose_name='date published', null=True, blank=True)),
                ('get_file', models.IntegerField(null=True, blank=True)),
                ('published', models.CharField(max_length=255, null=True, blank=True)),
                ('docfile', models.FileField(upload_to=submit.models.file, null=True, blank=True)),
                ('md5', models.CharField(max_length=32)),
                ('summary', models.TextField(max_length=500, null=True, blank=True)),
                ('src_url', models.URLField(null=True, blank=True)),
                ('doc_url', models.URLField(null=True, blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Partners',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('partner_name', models.CharField(max_length=200, null=True, blank=True)),
                ('group', models.ForeignKey(to='submit.Groups')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
